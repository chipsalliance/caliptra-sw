# hwmodel

This example defines the Caliptra interface functions, allowing the generic application to communicate with the hardware model without having to directly manage model-specific details.

# Prerequisites

The c-binding, rom, and firmware must all be built.

# Build

Running "make" will compile the Caliptra C API, the interface, and link the application against the C binding.
